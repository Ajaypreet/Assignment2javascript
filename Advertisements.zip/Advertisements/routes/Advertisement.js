var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Advertisement = require('../models/Advertisement');
const passport = require('passport')
const User = require('../models/User')


router.get("/getdata",async (req, res) => {
	Advertisement.find((err, advertisements) => {
        if (err) {
            res.end(err)
        }
        else {
            res.send({advertisements})
        }
    })
})

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }), 
(req, res) => {})

router.get('/google/callback', passport.authenticate('google'), (req,res) =>{
  res.redirect('/')
})

router.get('/logout', (req, res) => {
  req.logout();
  res.redirect('/');
});


function isLoggedIn(req,res, next){
    if(req.isAuthenticated()){
        return next()
    }
    res.redirect('/')
} 

router.get("/", async (req, res) => {
	Advertisement.find((err, advertisements) => {
        if (err) {
            res.end(err)
        }
        else {
            res.render('index',
                {
                    advertisements: advertisements,
                    user: req.user
                })
        }
    })
})

router.get("/new", isLoggedIn,async (req, res) => {
	Advertisement.find((err, advertisements) => {
        if (err) {
            res.end(err)
        }
        else {
            res.render('advertisements/Add',
                {
                    user: req.user
                })
        }
    })
})

router.post("/Add", isLoggedIn, async (req, res) => {
Advertisement.create({
        Title: req.body.Title,
        Description: req.body.Description,
        Price: req.body.Price
    }, (err, advertisement) => {
        if(err)
        {
            res.end(err)
        }
        else
        {
            res.redirect('/')
        }
    })
})


router.get("/Edit/:_id", isLoggedIn,async (req, res) => {
	Advertisement.findById(req.params._id,(err, advertisement) => {
        if (err) {
            res.end(err)
        }
        else {
            res.render('advertisements/Edit',
                {
                    advertisement: advertisement,
                    user: req.user
                })
        }
    })
})

router.post("/update/:_id", isLoggedIn,async (req, res) => {
	
	var advertisement = req.body
	Advertisement.update({_id: req.params._id}, advertisement,(err) => {
        if(err)
        {
            res.end(err)
        }
        else
        {
            res.redirect('/')
        }
})
})

router.get("/delete/:_id", isLoggedIn,async (req, res) => {
	
	   Advertisement.remove({_id: req.params._id},(err,advertisement) => {
        if(err)
        {
            res.end(err)
        }
        else
        {
			res.redirect('/')
        }
})
})

module.exports = router;
