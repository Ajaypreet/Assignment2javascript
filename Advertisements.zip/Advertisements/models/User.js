const mongoose = require('mongoose');
const plm = require('passport-local-mongoose')

const User = new mongoose.Schema({
  id: String,
  username: String,
  create: Date
});

User.plugin(plm);

module.exports = mongoose.model('User', User);