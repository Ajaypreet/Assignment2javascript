var mongoose = require('mongoose');

var Advertisement = new mongoose.Schema({
  Title: String,
  Description: String,
  Price: Number
});

module.exports = mongoose.model('Advertisement', Advertisement);