var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const mongoose = require('mongoose')

const globals = require('./config/globals')

var AdvertisementRouter = require('./routes/Advertisement');
var usersRouter = require('./routes/users');

const passport = require('passport')
const session = require('express-session')
var app = express();


mongoose.connect(globals.db,
    {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }).then(
    (res) => {
      console.log('Connected to MongoDB')
    }
).catch(() => {
  console.log('No Connection to MongoDB')
})

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized:false
}))


app.use(passport.initialize())
app.use(passport.session())

const User = require('./models/User')

passport.use(User.createStrategy())

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((id, done) => {
  User.findById(id).then(user => {
    done(null, user);
  });
});

const GoogleStrategy = require('passport-google-oauth20').Strategy

passport.use(new GoogleStrategy({
    clientID: globals.ids.google.clientID,
    clientSecret: globals.ids.google.clientSecret,
    callbackURL: globals.ids.google.callbackURL
},
    (token, tokenSecret, profile, done) => {
			User.findOne({Id: profile.id}, (err, user)=>{
            if(err)
            {
                console.log(err) //error
            }
            if (!err && user != null)
            {
                done(null, user)
            }
            else
            {
                user = new User({
                    id: profile.id,
                    username: profile.displayName,
                    create: Date.now(),
                })
                user.save((err) => {
                    if(err)
                    {
                        console.log(err)
                    }
                    else
                    {
                        return done(null, user)
                    }
                })
            }
        })
    }
))


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', AdvertisementRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
