module.exports =
    {
    'db': 'mongodb+srv://ajaypreet:ajaypreet@cluster0.rdvgo.mongodb.net/ajaypreet?retryWrites=true&w=majority',
        ids: {
        'google': {
            clientID: '795407678301-0ta4od3k7ghl8verkahrhpk61firj6mv.apps.googleusercontent.com',
            clientSecret: 'TcLAJt85Z-h2hM3TdXMVTm0a',
            callbackURL: 'http://localhost:3000/google/callback'
        },
        }
}